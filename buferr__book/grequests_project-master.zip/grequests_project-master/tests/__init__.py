#!/usr/bin/env python
# encoding: utf-8

"""
@author: zhanghe
@software: PyCharm
@file: __init__.py.py
@time: 2017-12-04 11:36
"""


def func():
    pass


class Main(object):
    def __init__(self):
        pass


if __name__ == '__main__':
    pass
